import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button.jsx'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { ScrollArea } from '@/components/ui/scroll-area.jsx'
import { Separator } from '@/components/ui/separator.jsx'
import { Input } from '@/components/ui/input.jsx'
import { 
  BookOpen, 
  FileText, 
  Layout, 
  List, 
  Quote, 
  Link, 
  CheckSquare,
  Menu,
  X,
  Home,
  Search,
  ChevronRight,
  Download,
  Moon,
  Sun,
  ArrowUp,
  ExternalLink
} from 'lucide-react'
import './App.css'

function App() {
  const [activeSection, setActiveSection] = useState('home')
  const [sidebarOpen, setSidebarOpen] = useState(false)
  const [searchTerm, setSearchTerm] = useState('')
  const [darkMode, setDarkMode] = useState(false)
  const [showScrollTop, setShowScrollTop] = useState(false)

  // Toggle dark mode
  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add('dark')
    } else {
      document.documentElement.classList.remove('dark')
    }
  }, [darkMode])

  // Show scroll to top button
  useEffect(() => {
    const handleScroll = () => {
      setShowScrollTop(window.scrollY > 300)
    }
    window.addEventListener('scroll', handleScroll)
    return () => window.removeEventListener('scroll', handleScroll)
  }, [])

  const sections = [
    {
      id: 'home',
      title: 'Início',
      icon: Home,
      content: 'home',
      searchable: 'início home manual normalização cefet-mg trabalhos acadêmicos'
    },
    {
      id: 'introducao',
      title: '1. Introdução',
      icon: BookOpen,
      content: 'introducao',
      searchable: 'introdução objetivos finalidade como usar manual'
    },
    {
      id: 'estrutura',
      title: '2. Estrutura do Trabalho Acadêmico',
      icon: Layout,
      content: 'estrutura',
      searchable: 'estrutura trabalho acadêmico elementos pré-textuais textuais pós-textuais',
      subsections: [
        { id: 'parte-externa', title: '2.1 Parte Externa', searchable: 'capa lombada parte externa' },
        { id: 'elementos-pre-textuais', title: '2.2 Elementos Pré-textuais', searchable: 'folha rosto resumo sumário dedicatória agradecimentos' },
        { id: 'elementos-textuais', title: '2.3 Elementos Textuais', searchable: 'introdução desenvolvimento conclusão' },
        { id: 'elementos-pos-textuais', title: '2.4 Elementos Pós-textuais', searchable: 'referências glossário apêndice anexo índice' },
        { id: 'normas-gerais', title: '2.5 Normas Gerais de Apresentação', searchable: 'formato espaçamento notas rodapé numeração paginação' }
      ]
    },
    {
      id: 'relatorios',
      title: '3. Relatórios',
      icon: FileText,
      content: 'relatorios',
      searchable: 'relatórios estágio técnico científico',
      subsections: [
        { id: 'relatorio-estagio', title: '3.1 Relatórios de Estágio', searchable: 'relatório estágio' },
        { id: 'relatorio-tecnico', title: '3.2 Relatório Técnico e/ou Científico', searchable: 'relatório técnico científico' }
      ]
    },
    {
      id: 'projeto-pesquisa',
      title: '4. Projeto de Pesquisa',
      icon: Search,
      content: 'projeto-pesquisa',
      searchable: 'projeto pesquisa metodologia objetivos justificativa cronograma'
    },
    {
      id: 'artigos',
      title: '5. Artigos Científicos',
      icon: FileText,
      content: 'artigos',
      searchable: 'artigos científicos formatação estrutura'
    },
    {
      id: 'citacoes',
      title: '6. Citações',
      icon: Quote,
      content: 'citacoes',
      searchable: 'citações direta indireta apud aspas'
    },
    {
      id: 'referencias',
      title: '7. Referências',
      icon: Link,
      content: 'referencias',
      searchable: 'referências abnt nbr 6023 bibliografia'
    },
    {
      id: 'checklist',
      title: '8. Checklist de Verificação',
      icon: CheckSquare,
      content: 'checklist',
      searchable: 'checklist verificação conferir trabalho'
    }
  ]

  const filteredSections = sections.filter(section => {
    if (!searchTerm) return true
    const searchLower = searchTerm.toLowerCase()
    return section.searchable.toLowerCase().includes(searchLower) ||
           section.title.toLowerCase().includes(searchLower) ||
           (section.subsections && section.subsections.some(sub => 
             sub.searchable.toLowerCase().includes(searchLower) ||
             sub.title.toLowerCase().includes(searchLower)
           ))
  })

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' })
  }

  const renderContent = () => {
    switch (activeSection) {
      case 'home':
        return (
          <div className="space-y-8">
            {/* Hero Section */}
            <div className="bg-gradient-to-r from-blue-900 to-blue-700 text-white p-8 rounded-lg">
              <h1 className="text-4xl font-bold mb-4">Manual de Normalização de Trabalhos Acadêmicos</h1>
              <p className="text-xl mb-6">Centro Federal de Educação Tecnológica de Minas Gerais</p>
              <div className="flex flex-wrap gap-4">
                <Badge variant="secondary" className="text-sm">2ª Edição - 2024</Badge>
                <Badge variant="secondary" className="text-sm">145 páginas</Badge>
                <Badge variant="secondary" className="text-sm">ISBN: 978-65-87888-27-9</Badge>
              </div>
            </div>

            {/* Quick Access Cards */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              <Card className="hover:shadow-lg transition-all duration-300 hover:scale-105 cursor-pointer" onClick={() => setActiveSection('estrutura')}>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Layout className="h-5 w-5 text-blue-600" />
                    Estrutura do Trabalho
                  </CardTitle>
                  <CardDescription>
                    Elementos pré-textuais, textuais e pós-textuais
                  </CardDescription>
                </CardHeader>
              </Card>

              <Card className="hover:shadow-lg transition-all duration-300 hover:scale-105 cursor-pointer" onClick={() => setActiveSection('citacoes')}>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Quote className="h-5 w-5 text-green-600" />
                    Citações
                  </CardTitle>
                  <CardDescription>
                    Citações diretas, indiretas e de citação
                  </CardDescription>
                </CardHeader>
              </Card>

              <Card className="hover:shadow-lg transition-all duration-300 hover:scale-105 cursor-pointer" onClick={() => setActiveSection('referencias')}>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Link className="h-5 w-5 text-purple-600" />
                    Referências
                  </CardTitle>
                  <CardDescription>
                    Normas para elaboração de referências
                  </CardDescription>
                </CardHeader>
              </Card>

              <Card className="hover:shadow-lg transition-all duration-300 hover:scale-105 cursor-pointer" onClick={() => setActiveSection('relatorios')}>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <FileText className="h-5 w-5 text-orange-600" />
                    Relatórios
                  </CardTitle>
                  <CardDescription>
                    Relatórios de estágio e técnico-científicos
                  </CardDescription>
                </CardHeader>
              </Card>

              <Card className="hover:shadow-lg transition-all duration-300 hover:scale-105 cursor-pointer" onClick={() => setActiveSection('artigos')}>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <FileText className="h-5 w-5 text-red-600" />
                    Artigos Científicos
                  </CardTitle>
                  <CardDescription>
                    Estrutura e formatação de artigos
                  </CardDescription>
                </CardHeader>
              </Card>

              <Card className="hover:shadow-lg transition-all duration-300 hover:scale-105 cursor-pointer" onClick={() => setActiveSection('checklist')}>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <CheckSquare className="h-5 w-5 text-teal-600" />
                    Checklist
                  </CardTitle>
                  <CardDescription>
                    Verificação final dos trabalhos
                  </CardDescription>
                </CardHeader>
              </Card>
            </div>

            {/* About Section */}
            <Card>
              <CardHeader>
                <CardTitle>Sobre este Manual</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground mb-4">
                  Este manual foi desenvolvido pelo Sistema de Bibliotecas do CEFET-MG para orientar estudantes, 
                  professores e pesquisadores na elaboração de trabalhos acadêmicos seguindo as normas da ABNT.
                </p>
                <div className="space-y-2">
                  <p><strong>Organização:</strong> Sistema de Bibliotecas do CEFET-MG</p>
                  <p><strong>Revisão gramatical:</strong> Fábio Luiz Nunes</p>
                  <p><strong>Edição:</strong> 2ª edição, Belo Horizonte, 2024</p>
                </div>
              </CardContent>
            </Card>
          </div>
        )

      case 'introducao':
        return (
          <div className="space-y-6">
            <div>
              <h1 className="text-3xl font-bold mb-4">1. Introdução</h1>
              <Separator className="mb-6" />
            </div>
            
            <Card>
              <CardContent className="pt-6">
                <p className="text-lg leading-relaxed mb-4">
                  Este manual tem como objetivo orientar a comunidade acadêmica do CEFET-MG na elaboração 
                  de trabalhos acadêmicos, seguindo as normas estabelecidas pela Associação Brasileira de 
                  Normas Técnicas (ABNT).
                </p>
                
                <p className="leading-relaxed mb-4">
                  A normalização de trabalhos acadêmicos é fundamental para garantir a qualidade, 
                  padronização e credibilidade das produções científicas. Este documento apresenta 
                  diretrizes claras e exemplos práticos para a elaboração de diferentes tipos de 
                  trabalhos acadêmicos.
                </p>

                <div className="bg-blue-50 dark:bg-blue-900/20 p-4 rounded-lg mt-6">
                  <h3 className="font-semibold mb-2">Objetivos do Manual:</h3>
                  <ul className="list-disc list-inside space-y-1 text-sm">
                    <li>Padronizar a apresentação de trabalhos acadêmicos</li>
                    <li>Facilitar a compreensão das normas ABNT</li>
                    <li>Fornecer exemplos práticos de aplicação</li>
                    <li>Orientar sobre diferentes tipos de trabalhos</li>
                  </ul>
                </div>
              </CardContent>
            </Card>
          </div>
        )

      case 'estrutura':
        return (
          <div className="space-y-6">
            <div>
              <h1 className="text-3xl font-bold mb-4">2. Estrutura do Trabalho Acadêmico</h1>
              <Separator className="mb-6" />
            </div>

            <div className="grid gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Layout className="h-5 w-5" />
                    2.1 Parte Externa
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="border-l-4 border-blue-500 pl-4">
                      <h4 className="font-semibold mb-2">Capa</h4>
                      <p className="text-sm text-muted-foreground">
                        Elemento obrigatório que contém informações essenciais para identificação do trabalho.
                      </p>
                    </div>
                    <div className="border-l-4 border-gray-300 pl-4">
                      <h4 className="font-semibold mb-2">Lombada</h4>
                      <p className="text-sm text-muted-foreground">
                        Elemento opcional que facilita a identificação do trabalho quando arquivado.
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <List className="h-5 w-5" />
                    2.2 Elementos Pré-textuais
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-3">
                      <Badge variant="outline" className="mb-2">Obrigatórios</Badge>
                      <div className="space-y-2">
                        <div className="flex items-center gap-2">
                          <div className="w-2 h-2 bg-red-500 rounded-full"></div>
                          <span className="text-sm">Folha de Rosto</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <div className="w-2 h-2 bg-red-500 rounded-full"></div>
                          <span className="text-sm">Resumo na língua vernácula</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <div className="w-2 h-2 bg-red-500 rounded-full"></div>
                          <span className="text-sm">Sumário</span>
                        </div>
                      </div>
                    </div>
                    <div className="space-y-3">
                      <Badge variant="secondary" className="mb-2">Opcionais</Badge>
                      <div className="space-y-2">
                        <div className="flex items-center gap-2">
                          <div className="w-2 h-2 bg-gray-400 rounded-full"></div>
                          <span className="text-sm">Dedicatória</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <div className="w-2 h-2 bg-gray-400 rounded-full"></div>
                          <span className="text-sm">Agradecimentos</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <div className="w-2 h-2 bg-gray-400 rounded-full"></div>
                          <span className="text-sm">Epígrafe</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <div className="w-2 h-2 bg-gray-400 rounded-full"></div>
                          <span className="text-sm">Lista de ilustrações</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <div className="w-2 h-2 bg-gray-400 rounded-full"></div>
                          <span className="text-sm">Lista de tabelas</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <div className="w-2 h-2 bg-gray-400 rounded-full"></div>
                          <span className="text-sm">Lista de siglas</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <FileText className="h-5 w-5" />
                    2.3 Elementos Textuais
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="border-l-4 border-green-500 pl-4">
                      <h4 className="font-semibold mb-2">Introdução</h4>
                      <p className="text-sm text-muted-foreground">
                        Apresentação do tema, objetivos, justificativa e metodologia.
                      </p>
                    </div>
                    <div className="border-l-4 border-blue-500 pl-4">
                      <h4 className="font-semibold mb-2">Desenvolvimento</h4>
                      <p className="text-sm text-muted-foreground">
                        Corpo principal do trabalho, dividido em capítulos e seções.
                      </p>
                    </div>
                    <div className="border-l-4 border-purple-500 pl-4">
                      <h4 className="font-semibold mb-2">Conclusão</h4>
                      <p className="text-sm text-muted-foreground">
                        Síntese dos resultados e considerações finais.
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Link className="h-5 w-5" />
                    2.4 Elementos Pós-textuais
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-3">
                      <Badge variant="outline" className="mb-2">Obrigatórios</Badge>
                      <div className="space-y-2">
                        <div className="flex items-center gap-2">
                          <div className="w-2 h-2 bg-red-500 rounded-full"></div>
                          <span className="text-sm">Referências</span>
                        </div>
                      </div>
                    </div>
                    <div className="space-y-3">
                      <Badge variant="secondary" className="mb-2">Opcionais</Badge>
                      <div className="space-y-2">
                        <div className="flex items-center gap-2">
                          <div className="w-2 h-2 bg-gray-400 rounded-full"></div>
                          <span className="text-sm">Glossário</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <div className="w-2 h-2 bg-gray-400 rounded-full"></div>
                          <span className="text-sm">Apêndice</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <div className="w-2 h-2 bg-gray-400 rounded-full"></div>
                          <span className="text-sm">Anexo</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <div className="w-2 h-2 bg-gray-400 rounded-full"></div>
                          <span className="text-sm">Índice</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        )

      case 'citacoes':
        return (
          <div className="space-y-6">
            <div>
              <h1 className="text-3xl font-bold mb-4">6. Citações</h1>
              <Separator className="mb-6" />
            </div>

            <div className="grid gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Quote className="h-5 w-5" />
                    6.1 Citação Direta
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-6">
                    <div>
                      <h4 className="font-semibold mb-3 flex items-center gap-2">
                        <div className="w-3 h-3 bg-blue-500 rounded-full"></div>
                        Citação Direta Curta (até 3 linhas)
                      </h4>
                      <p className="text-sm text-muted-foreground mb-3">
                        Incorporada ao texto, entre aspas duplas.
                      </p>
                      <div className="bg-gray-50 dark:bg-gray-800 p-4 rounded-lg border-l-4 border-blue-500">
                        <p className="text-sm font-mono">
                          Segundo Silva (2020, p. 15), <span className="text-blue-600">"a normalização é fundamental para a qualidade dos trabalhos acadêmicos"</span>.
                        </p>
                      </div>
                    </div>
                    
                    <div>
                      <h4 className="font-semibold mb-3 flex items-center gap-2">
                        <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                        Citação Direta Longa (mais de 3 linhas)
                      </h4>
                      <p className="text-sm text-muted-foreground mb-3">
                        Destacada do texto, com recuo de 4 cm, fonte menor e sem aspas.
                      </p>
                      <div className="bg-gray-50 dark:bg-gray-800 p-4 rounded-lg border-l-4 border-green-500">
                        <div className="ml-8 text-xs leading-relaxed">
                          A elaboração de trabalhos acadêmicos requer atenção especial às normas de formatação e apresentação. É necessário seguir rigorosamente as diretrizes estabelecidas para garantir a qualidade e credibilidade do trabalho científico (SANTOS, 2021, p. 45).
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <FileText className="h-5 w-5" />
                    6.2 Citação Indireta
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground mb-4">
                    Paráfrase das ideias do autor, sem aspas, mas com indicação da fonte.
                  </p>
                  <div className="bg-gray-50 dark:bg-gray-800 p-4 rounded-lg border-l-4 border-purple-500">
                    <p className="text-sm font-mono">
                      A normalização contribui significativamente para a padronização dos trabalhos científicos <span className="text-purple-600">(OLIVEIRA, 2019)</span>.
                    </p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <ExternalLink className="h-5 w-5" />
                    6.3 Citação de Citação
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground mb-4">
                    Citação de um texto ao qual não se teve acesso direto, usando "apud".
                  </p>
                  <div className="bg-gray-50 dark:bg-gray-800 p-4 rounded-lg border-l-4 border-orange-500">
                    <p className="text-sm font-mono">
                      Conforme mencionado por Costa <span className="text-orange-600">(1995 apud FERREIRA, 2020, p. 30)</span>, <span className="text-blue-600">"a pesquisa científica exige rigor metodológico"</span>.
                    </p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        )

      case 'referencias':
        return (
          <div className="space-y-6">
            <div>
              <h1 className="text-3xl font-bold mb-4">7. Referências</h1>
              <Separator className="mb-6" />
            </div>

            <Card>
              <CardContent className="pt-6">
                <p className="leading-relaxed mb-6">
                  As referências constituem uma lista ordenada dos documentos efetivamente citados no texto. 
                  Devem seguir as normas da ABNT NBR 6023:2018.
                </p>

                <div className="space-y-8">
                  <div>
                    <h3 className="font-semibold mb-4 text-lg">Exemplos de Referências:</h3>
                    
                    <div className="space-y-6">
                      <div>
                        <h4 className="font-medium mb-3 flex items-center gap-2">
                          <BookOpen className="h-4 w-4 text-blue-600" />
                          Livro com um autor:
                        </h4>
                        <div className="bg-gray-50 dark:bg-gray-800 p-4 rounded-lg border-l-4 border-blue-500">
                          <p className="text-sm font-mono">
                            SILVA, João Carlos. <strong>Metodologia científica</strong>. 3. ed. São Paulo: Atlas, 2020.
                          </p>
                        </div>
                      </div>

                      <div>
                        <h4 className="font-medium mb-3 flex items-center gap-2">
                          <FileText className="h-4 w-4 text-green-600" />
                          Artigo de periódico:
                        </h4>
                        <div className="bg-gray-50 dark:bg-gray-800 p-4 rounded-lg border-l-4 border-green-500">
                          <p className="text-sm font-mono">
                            SANTOS, Maria Fernanda. A importância da normalização. <strong>Revista Científica</strong>, São Paulo, v. 15, n. 2, p. 45-60, jul./dez. 2021.
                          </p>
                        </div>
                      </div>

                      <div>
                        <h4 className="font-medium mb-3 flex items-center gap-2">
                          <ExternalLink className="h-4 w-4 text-purple-600" />
                          Documento eletrônico:
                        </h4>
                        <div className="bg-gray-50 dark:bg-gray-800 p-4 rounded-lg border-l-4 border-purple-500">
                          <p className="text-sm font-mono">
                            OLIVEIRA, Pedro. <strong>Normas ABNT</strong>: guia prático. 2019. Disponível em: https://www.exemplo.com.br. Acesso em: 15 mar. 2022.
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="bg-yellow-50 dark:bg-yellow-900/20 p-4 rounded-lg">
                    <h4 className="font-semibold mb-2 text-yellow-800 dark:text-yellow-200">Dica Importante:</h4>
                    <p className="text-sm text-yellow-700 dark:text-yellow-300">
                      As referências devem ser organizadas em ordem alfabética pelo sobrenome do primeiro autor e alinhadas à margem esquerda.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        )

      case 'checklist':
        return (
          <div className="space-y-6">
            <div>
              <h1 className="text-3xl font-bold mb-4">8. Checklist de Verificação</h1>
              <Separator className="mb-6" />
            </div>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <CheckSquare className="h-5 w-5" />
                  Pontos de Verificação
                </CardTitle>
                <CardDescription>
                  Use esta lista para conferir se seu trabalho está de acordo com as normas
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="space-y-3">
                    <h4 className="font-semibold">Elementos Obrigatórios:</h4>
                    <div className="space-y-2">
                      {[
                        'Capa com todas as informações necessárias',
                        'Folha de rosto completa',
                        'Resumo na língua vernácula',
                        'Sumário com numeração correta',
                        'Introdução, desenvolvimento e conclusão',
                        'Referências formatadas segundo ABNT'
                      ].map((item, index) => (
                        <div key={index} className="flex items-center gap-3 p-2 rounded hover:bg-gray-50 dark:hover:bg-gray-800">
                          <div className="w-4 h-4 border-2 border-gray-300 rounded"></div>
                          <span className="text-sm">{item}</span>
                        </div>
                      ))}
                    </div>
                  </div>

                  <Separator />

                  <div className="space-y-3">
                    <h4 className="font-semibold">Formatação:</h4>
                    <div className="space-y-2">
                      {[
                        'Fonte Arial ou Times New Roman, tamanho 12',
                        'Espaçamento 1,5 entre linhas',
                        'Margens: superior e esquerda 3cm, inferior e direita 2cm',
                        'Numeração de páginas correta',
                        'Citações formatadas adequadamente',
                        'Figuras e tabelas numeradas e com fonte'
                      ].map((item, index) => (
                        <div key={index} className="flex items-center gap-3 p-2 rounded hover:bg-gray-50 dark:hover:bg-gray-800">
                          <div className="w-4 h-4 border-2 border-gray-300 rounded"></div>
                          <span className="text-sm">{item}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        )

      default:
        return (
          <div className="flex items-center justify-center h-64">
            <div className="text-center">
              <FileText className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
              <p className="text-muted-foreground">Conteúdo em desenvolvimento...</p>
            </div>
          </div>
        )
    }
  }

  return (
    <div className="min-h-screen bg-background transition-colors duration-300">
      {/* Header */}
      <header className="bg-white dark:bg-gray-900 border-b sticky top-0 z-50 transition-colors duration-300">
        <div className="flex items-center justify-between px-4 py-3">
          <div className="flex items-center gap-3">
            <Button
              variant="ghost"
              size="sm"
              className="md:hidden"
              onClick={() => setSidebarOpen(!sidebarOpen)}
            >
              {sidebarOpen ? <X className="h-4 w-4" /> : <Menu className="h-4 w-4" />}
            </Button>
            <div className="flex items-center gap-2">
              <BookOpen className="h-6 w-6 text-blue-600" />
              <h1 className="font-bold text-lg">Manual CEFET-MG</h1>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setDarkMode(!darkMode)}
            >
              {darkMode ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}
            </Button>
            <Button variant="outline" size="sm">
              <Download className="h-4 w-4 mr-2" />
              PDF Original
            </Button>
          </div>
        </div>
      </header>

      <div className="flex">
        {/* Sidebar */}
        <aside className={`${sidebarOpen ? 'translate-x-0' : '-translate-x-full'} md:translate-x-0 fixed md:static inset-y-0 left-0 z-40 w-64 bg-white dark:bg-gray-900 border-r transition-all duration-300 ease-in-out`}>
          <ScrollArea className="h-full">
            <div className="p-4">
              {/* Search */}
              <div className="mb-4">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input
                    placeholder="Buscar no manual..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10"
                  />
                </div>
              </div>

              <nav className="space-y-2">
                {filteredSections.map((section) => (
                  <div key={section.id}>
                    <Button
                      variant={activeSection === section.id ? "default" : "ghost"}
                      className="w-full justify-start text-left transition-all duration-200 hover:scale-105"
                      onClick={() => {
                        setActiveSection(section.id)
                        setSidebarOpen(false)
                      }}
                    >
                      <section.icon className="h-4 w-4 mr-2" />
                      {section.title}
                    </Button>
                    {section.subsections && activeSection === section.id && (
                      <div className="ml-6 mt-2 space-y-1 animate-in slide-in-from-left-2 duration-200">
                        {section.subsections.map((subsection) => (
                          <Button
                            key={subsection.id}
                            variant="ghost"
                            size="sm"
                            className="w-full justify-start text-left text-xs hover:bg-muted/50"
                          >
                            <ChevronRight className="h-3 w-3 mr-1" />
                            {subsection.title}
                          </Button>
                        ))}
                      </div>
                    )}
                  </div>
                ))}
              </nav>
            </div>
          </ScrollArea>
        </aside>

        {/* Main Content */}
        <main className="flex-1 p-6 md:p-8">
          <div className="max-w-4xl mx-auto">
            {renderContent()}
          </div>
        </main>
      </div>

      {/* Mobile Overlay */}
      {sidebarOpen && (
        <div 
          className="fixed inset-0 bg-black bg-opacity-50 z-30 md:hidden transition-opacity duration-300"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      {/* Scroll to Top Button */}
      {showScrollTop && (
        <Button
          className="fixed bottom-6 right-6 rounded-full w-12 h-12 shadow-lg transition-all duration-300 hover:scale-110"
          onClick={scrollToTop}
        >
          <ArrowUp className="h-4 w-4" />
        </Button>
      )}
    </div>
  )
}

export default App
